﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Excel = Microsoft.Office.Interop.Excel;

namespace WebApplication3
{
    public partial class ShowInfo : System.Web.UI.Page
    {
        public static List<User> users { get; set; }
        protected void Page_Load(object sender, EventArgs e)
        {

            if(users == null)
            {
                //读取excel
                users = new List<User>();
                User u1 = new User();
                u1.id = 1001; u1.name = "liming"; u1.age = 15; u1.gender = "男"; u1.nationality = "汉"; u1.phone = "13345621234";u1.address = "111111111111";
                User u2 = new User();
                u2.id = 1002; u2.name = "lili"; u2.age = 15; u2.gender = "男"; u2.nationality = "汉"; u2.phone = "13345621234"; u2.address = "111111111111";
                User u3 = new User();
                u3.id = 1003; u3.name = "wangzi"; u3.age = 15; u3.gender = "男"; u3.nationality = "汉"; u3.phone = "13345621234"; u3.address = "111111111111";
                users.Add(u1); users.Add(u2); users.Add(u3);
            }
            

        }



    }
}