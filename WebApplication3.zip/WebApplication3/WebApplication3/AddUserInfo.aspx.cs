﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication3
{
    public partial class AddUserInfo : System.Web.UI.Page
    {
     
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack)
            {
                User user = new User();
                user.name = Request.Form["username"];
                user.age = Convert.ToInt32(Request.Form["age"]);
                user.gender = Request.Form["gender"];
                user.phone = Request.Form["phone"];
                user.address = Request.Form["address"];
                user.nationality = Request.Form["nationality"];
                List<User> users = ShowInfo.users;
                int maxid = 0;
                foreach (User u in users)
                {
                    if (u.id > maxid)
                    {
                        maxid = u.id;
                    }
                }
                user.id = maxid + 1;

                users.Add(user);
                Response.Redirect("ShowInfo.aspx");
            }
           
        }
    }
}